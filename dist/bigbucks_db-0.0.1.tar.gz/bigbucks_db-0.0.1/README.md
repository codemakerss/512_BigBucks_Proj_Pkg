# 512_BigBucks_Proj_Pkg Documentation

## Preview

This is for FINTECH 512 Group Project Backend Supabase Database.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `bigbucks_db`.

```bash
pip install bigbucks_db
```

## Update

Use the package manager [pip](https://pip.pypa.io/en/stable/) to upgrade `bigbucks_db`.

